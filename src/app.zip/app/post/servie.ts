export interface MapObj {
  userId: number,
  id: number,
  title: string,
  body: string
}
