import {Component} from '@angular/core';
import {MapObj} from "./servie";
import {ServService} from "./serv.service";

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent {
  private posts: MapObj[] = []

  constructor(private po: ServService) {
    this.po.serv.subscribe((res: MapObj[]) => {
      this.posts = res;
    })
  }

  createPost(title: HTMLInputElement, body: HTMLInputElement) {
    let post: MapObj = {title: title, body: body}
    this.po.httpElement.post(this.po.myUrl,post).subscribe((data: MapObj) => {
      console.log(data);
    })
  }

  get Posts() {
    return this.posts
  }
}
